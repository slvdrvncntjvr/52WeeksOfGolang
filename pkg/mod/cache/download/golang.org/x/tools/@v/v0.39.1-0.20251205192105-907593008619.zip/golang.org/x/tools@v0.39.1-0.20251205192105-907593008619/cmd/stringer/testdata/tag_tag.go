// This file has a build tag "tag"

// +build tag

package main

const TagProtected Const = C + 1
