// This file ensures that the package is non-empty
// in every build configuration.

package plusbuild
