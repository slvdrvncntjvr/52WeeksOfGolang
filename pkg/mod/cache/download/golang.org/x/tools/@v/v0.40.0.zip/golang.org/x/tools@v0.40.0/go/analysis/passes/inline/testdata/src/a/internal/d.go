// According to the go toolchain's rule about internal packages,
// this package is visible to package a, but not package b.
package internal

const D = 1

type T int
