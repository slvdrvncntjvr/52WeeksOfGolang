package issue76616

func _() {
	_ = func() {}
}
