// Code generated with somegen DO NOT EDIT.
//
// Because this file is generated, there should be no diagnostics
// reported for any unused parameters.

package generatedcode

// generatedInterface exists to ensure that the generated code
// is considered when determining whether parameters are used
// in non-generated code.
type generatedInterface interface{ n(f bool) }

func a(x bool) { println() }

var v = func(x bool) { println() }
